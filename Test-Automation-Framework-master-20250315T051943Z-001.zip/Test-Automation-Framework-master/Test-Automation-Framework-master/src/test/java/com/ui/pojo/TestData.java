package com.ui.pojo;

import java.util.List;

public class TestData {

	List<User>data;

	public List<User> getData() {
		return data;
	}

	public void setData(List<User> data) {
		this.data = data;
	}
	
	
}

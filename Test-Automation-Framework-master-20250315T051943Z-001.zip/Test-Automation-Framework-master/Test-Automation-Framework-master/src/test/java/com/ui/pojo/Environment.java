package com.ui.pojo;

public class Environment { 
	private String url;
	private int MAX_NUMBER_OF_ATTEMPTS;

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public int getMAX_NUMBER_OF_ATTEMPTS() {
		return MAX_NUMBER_OF_ATTEMPTS;
	}

	public void setMAX_NUMBER_OF_ATTEMPTS(int mAX_NUMBER_OF_ATTEMPTS) {
		MAX_NUMBER_OF_ATTEMPTS = mAX_NUMBER_OF_ATTEMPTS;
	}
	
	

}

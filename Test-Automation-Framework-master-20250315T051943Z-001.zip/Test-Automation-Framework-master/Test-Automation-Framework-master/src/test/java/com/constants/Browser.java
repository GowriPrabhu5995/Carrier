package com.constants;

public enum Browser {
	CHROME,FIREFOX,EDGE

}

package com.constants;

public enum Env {
	QA,DEV,UAT

}

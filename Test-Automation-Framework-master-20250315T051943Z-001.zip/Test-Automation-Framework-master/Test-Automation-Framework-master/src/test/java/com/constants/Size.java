package com.constants;

public enum Size {
  S,M,L
}
